
"use strict";

let saveMap = require('./saveMap.js')

module.exports = {
  saveMap: saveMap,
};
